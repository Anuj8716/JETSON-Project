#!/bin/bash

sudo docker rmi youjiang9977/llama-factory:r35.4.1
sudo rm -rf /home/$USER/reComputer/jetson-containers/LLaMA-Factory/*
