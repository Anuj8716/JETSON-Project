#!/bin/bash

# Let's allow connections
xhost +local:docker


