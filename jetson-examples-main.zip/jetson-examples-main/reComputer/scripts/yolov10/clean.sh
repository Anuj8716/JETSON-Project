#!/bin/bash

sudo docker rmi youjiang9977/yolov10-jetson:5.1.1
sudo rm -rf /home/$USER/reComputer/yolov10
