#!/bin/bash

# remove docker image
sudo docker rmi feiticeir0/movenetjs:latest 
