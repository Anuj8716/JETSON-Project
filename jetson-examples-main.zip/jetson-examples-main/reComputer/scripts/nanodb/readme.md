# NanoDB

## ref

- <https://www.jetson-ai-lab.com/tutorial_nanodb.html>

## access

- using in machine, try `http://127.0.0.1:7860` in browser.
- using in other pc, make sure you know jetson's IP and try `http://<<Jetson's IP>>:7860` in browser.
