#!/bin/bash

# TODO: clean old container
docker rmi $(./autotag llava)