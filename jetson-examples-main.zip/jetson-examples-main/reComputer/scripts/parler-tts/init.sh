#!/bin/bash

echo "Creating models directory at /home/$USER/models"

# Create Model dir in User home
mkdir /home/$USER/models


