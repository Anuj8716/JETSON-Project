# Install

- use the way you like to install

## PyPI(recommend)

```sh
pip install jetson-examples
```

## Linux (github trick)

```sh
curl -fsSL https://raw.githubusercontent.com/Seeed-Projects/jetson-examples/main/install.sh | sh
```

## Github (for Developer)

```sh
git clone https://github.com/Seeed-Projects/jetson-examples
cd jetson-examples
pip install .
```
